<?php $__env->startComponent('mail::message'); ?>
# CPAR has been answered and finalized by department head <?php echo e($cpar->department_head); ?>


The CPAR that has been issued to
<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($employee->id == $cpar->person_responsible): ?>
        <strong><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></strong>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($cpar->created_at->diffForHumans()); ?> has been answered
and finalized and now ready to be reviewed.

<?php $__env->startComponent('mail::button', ['url' => route('cpars.review', $cpar->id)]); ?>
    Click here to start reviewing cpar
<?php echo $__env->renderComponent(); ?>

Thanks,
<?php echo e(config('app.name')); ?>


<?php $__env->slot('subcopy'); ?>
    <p style="text-align: center;">This is a computer generated email. Please do not reply. For inquiries kindly email as at <a href="#">it@newsim.ph</a></p>
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
