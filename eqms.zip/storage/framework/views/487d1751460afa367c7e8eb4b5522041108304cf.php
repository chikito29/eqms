<?php $__env->startSection('page-title'); ?>
    Home | eQMS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-home'); ?> active <?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="page-content-wrap" style="margin-top: 50px; height: 90vh;">

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">

                    <br><br>
                    <h1 style="text-align: center;">Welcome to eQMS!</h1><br><br>
                    <div style="text-align: center; padding-left:50px; padding-right:50px; padding-bottom:50px;">
                        <h4>
                        This site is currently being developed in an attempt to convert NSCPI's Quality Manuals into electronic format. We are hoping that through this system, we will be able to maintain and enhance the center's documented Quality Policies and Procedures more dynamically.<br><br><br>We are really working hard to create a highly usable system but since this is a work in progress, we wish to apologize in advance for momentary errors that you might encounter. Nevertheless, we will highly appreciate if you can notify us by dropping an email to <span style="font-weight: bold;">info@newsim.ph</span> should you encounter any.
                    </h4>
                    </div>

                </div>
            </div>
        </div>
    </div>

    
        
            
                

                    
                        
                            
                            
                                
                                    
                                    
                                        
                                        
                                    
                                
                            
                        
                        
                            
                                

                                    
                                    
                                    
                                    
                                
                                
                                    
                                        
                                            
                                                
                                                
                                            
                                            
                                        
                                        
                                        
                                        
                                    
                                
                            
                        
                    

                    
                        
                        
                        
                        
                        
                        
                        
                    

                
                

                    
                        
                            
                            
                                
                            
                        
                        
                            
                                
                                
                                
                            
                            
                                
                                    
                                        
                                            
                                            
                                            
                                        
                                        
                                            
                                        
                                        
                                            
                                        
                                    
                                
                            
                            
                                
                                    
                                
                            
                        
                    

                
            
        
    

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>