<?php if($slot == '1'): ?>
    <span class="label label-success" style="color: white;">Approved</span>
<?php else: ?>
    <span class="label label-danger" style="color: white;">Denied</span>
<?php endif; ?>
