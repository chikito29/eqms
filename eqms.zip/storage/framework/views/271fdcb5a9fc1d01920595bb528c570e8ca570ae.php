<?php $__env->startSection('page-title'); ?>
    CPAR Forms | Cpar Index
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-view'); ?> active <?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="page-content-wrap" style="margin-top: -25px;">
        <?php if(session('attention')): ?>
            <?php echo $__env->make('layouts.attention', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php elseif($errors <> null): ?>
            <?php echo $__env->make('errors.error-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        <div class="x-content" >
            <div class="x-content-inner" style="margin-top:-20px; height: 90vh;">
                <div class="row">
                    <div class="col-md-12">
                        <div class="x-block">
                            <div class="x-block-head">
                                <h3>CPAR List</h3>
                            </div>
                            <table class="table table-striped" id="cpars-table">
                                <thead>
                                <tr>
                                    <th>CPAR #</th>
                                    <th>RAISED BY</th>
                                    <th>SEVERITY</th>
                                    <th>ISSUED</th>
                                    <th>STATUS</th>
                                    <th with="120">Actions</th>
                                </tr>
                                </thead>
                                <tbody id="cpars-table-body">
                                <?php echo $__env->make('layouts.table-row-cpars', ['cpar'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('message-box'); ?>
    <div class="modal fade" id="confirm-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="modal-title">Close CPAR</h4>
                </div>
                <div class="modal-body" id="modal-body">
                    Are you sure you want to <span class="text text-danger">close</span> CPAR?
                </div>
                <div class="modal-footer" id="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="modal-yes">Yes, Close issued CPAR</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <div class="modal fade" id="cpar-number-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Create CPAR Number</h4>
                </div>
                <div class="modal-body">
                    <input type="text" class="form-control" name="cpar-number-input" required>
                    <span class="help text text-info">Enter the CPAR control number here.</span>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="saveCparNumber()" id="savebtn-modal">Save changes</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var confirmModalBody;
        cparId = '';

        $(function(){
            confirmModalBody = $('#confirm-modal').html();
        });

        function closeCpar(id){
            var cparId = id;
            $('#modal-yes').attr('onclick', '$("'+ "#close" + cparId + '").submit();');
            $('input:text[name="cpar_id"]').val(id);
            $('#confirm-modal').modal('toggle');
        }

        function checkButton(date, url){

            if(date == ""){
                $('#modal-title').empty().append('Attention');
                $('#modal-body').empty().append('Cpar has not yet been reviewed and confirmed by concerned person\'s department head');
                $('#modal-footer').empty().append('<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>');
                $('#confirm-modal').modal('toggle');
            }
            else
                window.location.href= url;
        }

        function openCparNumberModal(id) {
            cparId = id;
            $('#cpar-number-modal').modal('toggle');
        }

        function saveCparNumber() {
            $('#edit' + cparId).attr('action', '/cpars/create-cpar-number/' + cparId);
            $('input:text[name="cpar_number"]').val($('input:text[name="cpar-number-input"]').val());
            $('#edit' + cparId).submit();
        }
		if($('#cpars-table-body').children().length == 0) {
			$('#cpars-table-body').html('<tr><td colspan="6" align="center">No CPAR Available.</td></tr>');
		}
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>