<?php $__env->startSection('page-title'); ?>
    Home | Finalize CPAR
<?php $__env->stopSection(); ?>

<?php $__env->startSection('verify-button'); ?>
    <button type="button" class="btn btn-primary btn-rounded pull-right" onclick="finalizeCpar()" id="print-cpar">Finalize CPAR</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <div class="modal fade" id="verify-cpar">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Confirm Action</h4>
                </div>
                <div class="modal-body">
                    After verifying this cpar, responsible person under your department will not be able to make anymore
                    changes.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="submitFinalizedCpar()">Verify</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function finalizeCpar() {
            $('#verify-cpar').modal('toggle');
        }

        function submitFinalizedCpar() {
            $('#form-cpar').attr('action', '<?php echo e(route('cpars.finalize', $cpar->id)); ?>');
            $('#form-cpar').removeAttr('target');
            $('#form-cpar').submit();
        }
    </script>

    <script type="text/javascript" src="<?php echo e(url('js/plugins/summernote/summernote.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/bootstrap/bootstrap-select.js')); ?>"></script>
    <script type="text/javascript">
        $(function() {
            $('#summernote').summernote({
                height: 300,
                toolbar: [
                    ['misc', ['fullscreen']]
                ],
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cpars.show', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>