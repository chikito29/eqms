<div class="form-group">
<label class="col-md-3 col-xs-5 control-label">Denied Request</label>
<div class="col-md-9 col-xs-7">
    <a class="control-label" style="font-size: 1.5em;" href="<?php echo e(route('revision-requests.show', $revisionRequest->revision_request_id)); ?>" target="_blank">Click here to view denied Revision Request</a>
    </div>
</div>