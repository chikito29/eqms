<div class="form-group">
    <label class="col-md-3 col-xs-12 control-label"><?php echo e($label); ?></label>
    <div class="col-md-9 col-xs-12">
        <label class="control-label pull-left"><?php echo e($slot); ?></label>
		
        <?php if(isset($help)): ?>
            <span class="help-block"><?php echo e($help); ?></span>
        <?php endif; ?>
    </div>
</div>
