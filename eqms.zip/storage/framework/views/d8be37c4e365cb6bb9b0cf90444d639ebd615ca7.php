<div class="form-group">
    <label class="col-md-3 col-xs-5 control-label">Appeal Link</label>
    <div class="col-md-9 col-xs-7">
        <label class="control-label"><a href="<?php echo e(route('revision-requests.show', $revisionRequest->appeal_id)); ?>">SEE APPEAL HERE <span class="fa fa-external-link"></span></a></label>
    </div>
</div>