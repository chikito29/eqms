<?php if($title == 'review'): ?>
    <button id="review-btn" class="btn btn-info btn-rounded btn-sm <?php if($cpar->cparClosed->status == 1): ?> hidden <?php endif; ?>" onclick="checkButton('<?php echo e($cpar->date_confirmed); ?>', '<?php echo e(route('cpars.review', $cpar->id)); ?>')">
        <span class="fa fa-legal"> <?php echo e($slot); ?></span>
    </button>
<?php elseif($title == 'view'): ?>
    <button class="btn btn-default btn-rounded btn-sm" onclick="location.href='<?php echo e(route('cpars.show', $cpar->id)); ?>';">
        <span class="fa fa-share"> <?php echo e($slot); ?></span>
    </button>
<?php elseif($title == 'edit'): ?>
    <button id="edit-btn" class="btn btn-default btn-rounded btn-sm <?php if($cpar->cparReviewed->on_review == 1 || $cpar->cparClosed->status == 1 || $cpar->cparAnswered->status == 1): ?> hidden <?php endif; ?>" onclick="location.href='<?php echo e(route('cpars.edit', $cpar->id)); ?>';">
        <span class="fa fa-pencil"> <?php echo e($slot); ?></span>
    </button>
<?php elseif($title == 'close'): ?>
    <button id="close-btn" type="button" class="btn btn-primary btn-rounded btn-sm <?php if(($cpar->cparClosed->status == 1 || $cpar->cparReviewed->on_review == 1 || $cpar->cparAnswered->status == 1) && request('user.role') == 'Admin'): ?> <?php else: ?> hidden <?php endif; ?>" onclick="closeCpar(<?php echo e($cpar->id); ?>)">
        <span class="fa fa-times"> <?php echo e($slot); ?></span>
    </button>
<?php elseif($title == 'Create CPAR Number'): ?>
    <button id="create-cpar-number-btn" class="btn btn-info btn-rounded btn-sm <?php if((request('user.role') == 'document-controller' && request('user.branch') == 'Makati') && $cpar->cparReviewed->status == 1): ?> <?php else: ?> hidden <?php endif; ?>" onclick="openCparNumberModal(<?php echo e($cpar->id); ?>)">
        <span class="fa fa-plus"> <?php echo e($slot); ?></span>
    </button>
<?php elseif($title == 'Print Reviewed CPAR'): ?>
    <button id="print-reviewed-cpar-btn" class="btn btn-info btn-rounded btn-sm <?php if(! \App\HelperClasses\User::isDefault(request('user.id'))): ?> <?php else: ?> hidden <?php endif; ?>" onclick='window.open("<?php echo e(route('action-summary', $cpar->id)); ?>")'>
        <span class="fa fa-print"> <?php echo e($slot); ?></span>
    </button>
<?php elseif($title == 'Print Closed CPAR'): ?>
    <button id="print-closed-cpar-btn" class="btn btn-info btn-rounded btn-sm
    <?php if(request('user.type') <> 'role' || ($cpar->cparClosed->status <> 1 && $cpar->cparReviewed->status <> 1)): ?>
            hidden
    <?php endif; ?>"
        onclick='window.location.href = "<?php echo e(route('action-summary', $cpar->id)); ?>"'>
        <span class="fa fa-print"> <?php echo e($slot); ?></span>
    </button>
<?php endif; ?>
