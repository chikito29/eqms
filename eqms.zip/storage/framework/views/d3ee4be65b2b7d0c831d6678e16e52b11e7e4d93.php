<?php $__env->startComponent('mail::message'); ?>
# New Revision Request

You have a new revision request submission from <strong><?php echo e($revisionRequest->user_name); ?></strong>, submitted on <i><?php echo e($revisionRequest->created_at->toDayDateTimeString()); ?></i>.

<br><b>Reference document: </b>
<?php $__env->startComponent('mail::panel'); ?>
<a href="<?php echo e(route('documents.show', $revisionRequest->reference_document->id)); ?>"><?php echo e($revisionRequest->reference_document->title); ?></a>
<?php echo $__env->renderComponent(); ?>

<br><b>Reason for revision: </b>
<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($revisionRequest->revision_reason); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => route('revision-requests.show', $revisionRequest->id)]); ?>
Login to view Revision Request
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php $__env->startComponent('mail::subcopy'); ?>
<p style="text-align: center;">This is a computer generated email. Please do not reply. <br> For inquiries kindly email as at <a href="#">it@newsim.ph</a></p>
<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?>
