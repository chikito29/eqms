<?php $__env->startComponent('mail::message'); ?>
#
<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($employee->id == $cpar->person_responsible): ?>
        <strong><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>'s</strong>
		<?php break; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
CPAR has been reviewed

This is in regards with the CPAR issued to the above person.<br>
The QMR has reviewed the CPAR and came up with an appropriate action.<br>
Please see the CPAR in the provided link.

<?php $__env->startComponent('mail::button', ['url' => route('cpars.show', $cpar->id)]); ?>
    Click here to view reviewed CPAR
<?php echo $__env->renderComponent(); ?>

<?php $__env->slot('subcopy'); ?>
    <p style="text-align: center;">This is a computer generated email. Please do not reply. For inquiries kindly email as at <a href="#">it@newsim.ph</a></p>
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
