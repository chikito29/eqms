<div class="x-hnavigation no-print" style="margin-bottom: 30px;">
    <div class="x-hnavigation-logo">
        <a href="<?php echo e(url('/')); ?>">eQMS</a>
    </div>
    <ul>
        <li class="<?php echo $__env->yieldContent('nav-home'); ?>">
            <a href="<?php echo e(route('pages.dashboard')); ?>">Dashboard</a>
        </li>
        <li class="xn-openable <?php echo $__env->yieldContent('nav-document'); ?>">
            <a href="#">Procedures</a>
            <ul>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-circle"></span> <?php echo e($section->name); ?></a>
                        <ul>
                            <?php $__currentLoopData = $section->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('documents.show', $document->id)); ?>"><?php echo e($document->title); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li class="xn-openable <?php echo $__env->yieldContent('nav-view'); ?>">
            <a href="#">View</a>
            <ul>
                <li><a href="<?php echo e(route('revision-requests.index')); ?>"><span class="fa fa-paste"></span> Revision Requests</a></li>
                <li><a href="<?php echo e(route('access-requests.index')); ?>"><span class="fa fa-shield"></span> Access Requests</a></li>
                <li><a href="<?php echo e(route('cpars.index')); ?>"><span class="fa fa-list"></span> CPARs</a></li>
                <li><a href="<?php echo e(route('revision-logs.index')); ?>"><span class="fa fa-files-o"></span> Revision Logs</a></li>
            </ul>
        </li>
        <li class="xn-openable <?php echo $__env->yieldContent('nav-actions'); ?>">
            <a href="#">Actions</a>
            <ul>
                <li><a href="<?php echo e(route('documents.create')); ?>"><span class="fa fa-file-o"></span> New Document</a></li>
                <li><a href="<?php echo e(route('cpars.create')); ?>"><span class="fa fa-pencil-square-o"></span> Raise a CPAR</a></li>
            </ul>
        </li>
        <li class="xn-openable <?php echo $__env->yieldContent('nav-settings'); ?>">
            <a href="#">Settings</a>
            <ul>
                <li><a href="<?php echo e(route('sections.index')); ?>"><span class="fa fa-book"></span> Procedures</a></li>
            </ul>
        </li>
    </ul>
    <ul class="pull-right">
        <li class="xn-openable" style="margin: 0 -25px;">
            <a href="#"><strong><?php echo e(request('user.first_name')); ?> <?php echo e(request('user.last_name')); ?></strong></a>
            <ul>
                <li><a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span> Sign Out</a></li>
            </ul>
        </li>
        <div class="x-features pull-right">
            <div>
                <div class="x-features-search <?php if(request('search')): ?> active <?php endif; ?>">
                    <form class="form-horizontal" action="<?php echo e(route('documents.index')); ?>" method="get">
                        <input type="text" name="search" value="<?php if(request('search')): ?><?php echo e(request('search')); ?><?php endif; ?>">
                        <input type="submit">
                    </form>
                </div>
            </div>
        </div>
    </ul>
</div>
