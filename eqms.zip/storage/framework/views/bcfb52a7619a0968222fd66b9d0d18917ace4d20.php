<?php $__env->startComponent('mail::message'); ?>
# CPAR has been issued

You are receiving this because an employee under the department <?php echo e($cpar->department); ?> received a CPAR raised by
<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($employee->id == $cpar->raised_by): ?>
        <strong><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></strong>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>,
created this <?php echo e($cpar->created_at->format('l jS \\of F Y')); ?>.

Please inform
<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($employee->id == $cpar->person_responsible): ?>
        <strong><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></strong>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
to answer the CPAR on or before
<?php echo e(\App\Http\Controllers\CparController::holiday($cpar,2017,\Carbon\Carbon::parse($cpar->proposed_date),\Carbon\Carbon::parse($cpar->proposed_date)->diffInDays($cpar->created_at))->format('l jS \\of F Y')); ?>.

He/she may access the said CPAR using this code: <strong><?php echo e($cpar->responsiblePerson->code); ?></strong>

Person responsible may answer the CPAR here: <?php echo e(route('answer-cpar-login', $cpar->id)); ?>


<?php $__env->startComponent('mail::button', ['url' => route('cpars.show', $cpar->id)]); ?>
    Click here to view issued CPAR
<?php echo $__env->renderComponent(); ?>

<?php $__env->slot('subcopy'); ?>
    <p style="text-align: center;">This is a computer generated email. Please do not reply. For inquiries kindly email as at <a href="#">it@newsim.ph</a></p>
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
