<?php $__env->startSection('page-title'); ?>
    Home | Cpar Show
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-audit-findings'); ?> active <?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="page-content-wrap">
        <?php if(session('attention')): ?>
            <?php echo $__env->make('layouts.attention', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        <div class="page-title">
            <h2><span class="fa fa-pencil"></span> CORRECTIVE AND PREVENTIVE ACTION REPORT FORM</h2>
        </div>

        <div class="row">
            <div class="col-md-9">

                <form class="form-horizontal" role="form" id="form-cpar" action="/action-summary/<?php echo e($cpar->id); ?>" method="GET" target="_blank">
                    <?php echo e(csrf_field()); ?>

                    <div class="panel panel-default">
                        <div class="panel-body form-group-separated">
                            <?php if($cpar->cpar_number): ?>
                                <?php $__env->startComponent('components.show-single-line'); ?>
                                    <?php $__env->slot('label'); ?> CPAR Number <?php $__env->endSlot(); ?>
                                    <?php echo e($cpar->cpar_number); ?>

                                <?php echo $__env->renderComponent(); ?>
                            <?php endif; ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Raised By <?php $__env->endSlot(); ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->id == $cpar->raised_by): ?>
                                        <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Department <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->department); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Branch <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->branch); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Severity Of Findings <?php $__env->endSlot(); ?>
                                    <?php echo e(strip_tags(str_replace('&nbsp;', '', $cpar->severity))); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <div class="form-group">
                                <label class="col-md-3 col-xs-12 control-label">Procedure/Process/Scope/Other References</label>
                                <div class="col-md-9 col-xs-12">
                                    <textarea class="summernote" name="proposed_revision" id="summernote" disabled><?php echo $body; ?></textarea>
                                </div>
                            </div>
							<div class="form-group">
                                <label class="col-md-3 col-xs-12 control-label">Procedure/Process/Scope/Other References</label>
								<div class="col-md-9 col-xs-12">
	                                <?php $__currentLoopData = explode(',', $cpar->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                    <label style="border: solid 1px; border-color: rgb(220,220,220); padding: 4px 13px; border-radius: 3px; background-color: rgb(250,250,250);"><span class="fa fa-tag"> <?php echo e($tag); ?></span></label><br><br>
	                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
                            </div>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Source Of Non-Comformity <?php $__env->endSlot(); ?>
                                    <?php echo e($cpar->source); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-multi-line'); ?>
                                <?php $__env->slot('label'); ?> Others: (Please specify) <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->other_source); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-multi-line'); ?>
                                <?php $__env->slot('label'); ?> Details <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->details); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Person Reporting To Non-Conformity <?php $__env->endSlot(); ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->id == $cpar->raised_by): ?>
                                        <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Person Responsible For Taking The CPAR <?php $__env->endSlot(); ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->id == $cpar->person_responsible): ?>
                                        <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php if($cpar->correction): ?>
                                <?php $__env->startComponent('components.show-multi-line'); ?>
                                    <?php $__env->slot('label'); ?> Correction <?php $__env->endSlot(); ?>
                                    <?php echo e($cpar->correction); ?>

                                    <?php $__env->slot('help'); ?> Action To Eliminate The Detected Non-Conformity <?php $__env->endSlot(); ?>
                                <?php echo $__env->renderComponent(); ?>
                            <?php endif; ?>
                            <?php if($cpar->root_cause): ?>
                                <?php $__env->startComponent('components.show-multi-line'); ?>
                                    <?php $__env->slot('label'); ?> Root Cause Analysis <?php $__env->endSlot(); ?>
                                    <?php echo e($cpar->correction); ?>

                                    <?php $__env->slot('help'); ?> What Failed In The System To Allow This Non-Conformance To Occur? <?php $__env->endSlot(); ?>
                                <?php echo $__env->renderComponent(); ?>
                            <?php endif; ?>
                            <?php if($cpar->cp_action): ?>
                                <?php $__env->startComponent('components.show-multi-line'); ?>
                                    <?php $__env->slot('label'); ?> Corrective/Preventive Action <?php $__env->endSlot(); ?>
                                    <?php echo e($cpar->cp_action); ?>

                                    <?php $__env->slot('help'); ?> Specific Details Of Corrective Action Taken To Prevent Recurrence/Occurrence <?php $__env->endSlot(); ?>
                                <?php echo $__env->renderComponent(); ?>
                            <?php endif; ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Proposed Corrective Action Complete Date <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->proposed_date); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php if($cpar->date_completed): ?>
                                <?php $__env->startComponent('components.show-single-line'); ?>
                                    <?php $__env->slot('label'); ?> Corrective/Preventive Complete Date <?php $__env->endSlot(); ?>
                                    <?php echo e($cpar->date_completed); ?>

                                <?php echo $__env->renderComponent(); ?>
                            <?php endif; ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Department Head <?php $__env->endSlot(); ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->id == $cpar->chief): ?>
                                        <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php if($cpar->date_confirmed): ?>
                                <?php $__env->startComponent('components.show-single-line'); ?>
                                    <?php $__env->slot('label'); ?> Date Confirmed By Department Head <?php $__env->endSlot(); ?>
                                    <?php echo e($cpar->date_confirmed); ?>

                                <?php echo $__env->renderComponent(); ?>
                            <?php endif; ?>
                            <?php if($cpar->cparAnswered->status == 1): ?>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <h4><strong>To Be Filled By The QMR / Auditor</strong></h4>
                                    </div>
                                </div>
                                <?php if($cpar->cpar_acceptance): ?>
                                    <?php $__env->startComponent('components.show-multi-line'); ?>
                                        <?php $__env->slot('label'); ?> Acceptance of CPAR <?php $__env->endSlot(); ?>
                                        <?php echo e($cpar->cpar_acceptance); ?>

                                        <?php $__env->slot('help'); ?> Comments If Any <?php $__env->endSlot(); ?>
                                    <?php echo $__env->renderComponent(); ?>
                                <?php endif; ?>
                                <?php $__env->startComponent('components.show-single-line'); ?>
                                    <?php $__env->slot('label'); ?> Date Cpar Accepted <?php $__env->endSlot(); ?>
                                    <?php echo e($cpar->date_accepted); ?>

                                <?php echo $__env->renderComponent(); ?>
                                <?php if($cpar->verified_by): ?>
                                    <?php $__env->startComponent('components.show-single-line'); ?>
                                        <?php $__env->slot('label'); ?> Name <?php $__env->endSlot(); ?>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($employee->id == $cpar->verified_by): ?>
                                                <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__env->slot('help'); ?> QMR / AUDITOR / CEO <?php $__env->endSlot(); ?>
                                    <?php echo $__env->renderComponent(); ?>
                                <?php endif; ?>
                                <?php if($cpar->cpar_acceptance): ?>
                                    <?php $__env->startComponent('components.show-single-line'); ?>
                                        <?php $__env->slot('label'); ?> Verification Date <?php $__env->endSlot(); ?>
                                        <?php echo e($cpar->date_verified); ?>

                                    <?php echo $__env->renderComponent(); ?>
                                <?php endif; ?>
                                <?php if($cpar->result): ?>
                                    <?php $__env->startComponent('components.show-multi-line'); ?>
                                        <?php $__env->slot('label'); ?> Result Of Verification <?php $__env->endSlot(); ?>
                                        <?php echo e($cpar->result); ?>

                                    <?php echo $__env->renderComponent(); ?>
                                <?php endif; ?>
								<div class="form-group">
                                    <label class="col-md-3 col-xs-5 control-label">Attachments</label>
                                    <div class="col-md-9 col-xs-7">
										<?php if($cpar->attachments->count() > 0): ?>
                                            <?php if(request('user.role') == 'default'): ?>
                                                <label class="control-label">Confidential</label>
                                            <?php elseif(request('user.id') == $cpar->raised_by || request('user.id') == $cpar->person_responsible
                                            || request('user.role') == 'admin' || request('user.role') == 'document-controller'): ?>
                                                <?php $__currentLoopData = $cpar->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a class="control-label" href="<?php echo e(asset($attachment->file_path)); ?>" target="_blank"><?php echo e($attachment->file_name); ?></a> uploaded by: <?php echo e($attachment->uploaded_by); ?><br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            No Attachment Avaible For This CPAR
                                        <?php endif; ?>
									</div>
                                </div>
                                <div class="panel-footer">
                                    <?php echo $__env->yieldContent('verify-button'); ?>
                                    <?php if(request('user.role') == 'admin'): ?>
                                        <button class="btn btn-primary btn-rounded pull-right">Print CPAR</button>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
            </div>
            <div class="col-md-3">

                <div class="panel panel-default form-horizontal">
                    <div class="panel-body">
                        <h3><span class="fa fa-info-circle"></span> Quick Info</h3>
                        <p>Some quick info about this user</p>
                    </div>
                    <div class="panel-body form-group-separated">
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Role</label>
                            <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.role')); ?></div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Username</label>
                            <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.username')); ?></div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Department</label>
                            <div class="col-md-8 col-xs-7"><?php echo e(request('user.department')); ?></div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Branch</label>
                            <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.branch')); ?></div>
                        </div>
                    </div>

                </div>

            </div>

            </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->yieldContent('modals'); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/summernote/summernote.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/bootstrap/bootstrap-select.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('js/plugins/blueimp/jquery.blueimp-gallery.min.js')); ?>"></script>
    <script type="text/javascript">
        $(function(){
            var formBody = $('#form-cpar').html();

            $("#file-simple").fileinput({
                showUpload: false,
                showCaption: true,
                uploadUrl: "<?php echo e(route('revision-requests.store')); ?>",
                browseClass: "btn btn-primary",
                browseLabel: "Browse Document",
                allowedFileExtensions : ['.jpg']
            });
        });

        $('#summernote').summernote({
            height: 300,
            toolbar: [
                ['misc', ['fullscreen']]
            ],
        });

        function printCpar() {
            $('#form-cpar').html(formBody);
            $('#form-cpar').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>