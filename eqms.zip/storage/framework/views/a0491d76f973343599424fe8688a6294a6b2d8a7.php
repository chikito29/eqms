<?php if($cpar->cparClosed->status == 1 && $cpar->cparReviewed->status <> 1): ?>
    <span class="label label-primary">Closed <?php echo e($cpar->cparClosed->created_at->diffForHumans()); ?>

        closed by <?php echo e($cpar->cparClosed->closed_by); ?> <?php echo e($cpar->cparClosed->remarks); ?></span>
<?php elseif($cpar->cparClosed->status == 1 && $cpar->cparReviewed->status == 1): ?>
    <span class="label label-warning">CPAR reviewed by <?php echo e($cpar->cparReviewed->reviewed_by); ?> and closed <?php echo e($cpar->cparClosed->updated_at->diffForHumans()); ?>

        by <?php echo e($cpar->cparClosed->closed_by); ?></span>
<?php elseif($cpar->cpar_number == null && $cpar->cparReviewed->status == 1): ?>
	<span class="label label-success">CPAR reviewed <?php echo e($cpar->cparReviewed->updated_at->diffForHumans()); ?></span>
<?php elseif($cpar->cparReviewed->on_review == 1): ?>
    <span class="label label-warning">CPAR on review <?php echo e($cpar->cparReviewed->updated_at->diffForHumans()); ?></span>
<?php elseif($cpar->cparAnswered->status == 1 && $cpar->cparReviewed->status == 1): ?>
    <span class="label label-success">Reviewed <?php echo e($cpar->cparReviewed->created_at->diffForHumans()); ?> by <?php echo e($cpar->cparReviewed->reviewed_by); ?></span>
<?php elseif($cpar->cparAnswered->status <> 1): ?>
    <span class="label label-danger">No Response. Issued <?php echo e($cpar->created_at->diffForHumans()); ?></span>
<?php else: ?>
    <span class="label label-success">CPAR answered <?php echo e($cpar->cparAnswered->created_at->diffForHumans()); ?></span>
<?php endif; ?>
