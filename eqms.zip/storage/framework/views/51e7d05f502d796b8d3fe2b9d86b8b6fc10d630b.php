<?php $__currentLoopData = $cpars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if(request('user.role') != 'default'): ?>
		<tr>
			<td><?php echo e($cpar->cpar_number); ?></td>
			<td>
				<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($employee->id == $cpar->raised_by): ?>
						<?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</td>
			<td><?php echo $cpar->severity; ?></td>
			<td><?php echo e($cpar->created_at->toDayDateTimeString()); ?></td>
			<td>
				<?php echo $__env->make('components.status', compact('cpar'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</td>
			<td>
				<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> view <?php $__env->endSlot(); ?> view <?php echo $__env->renderComponent(); ?>
				<?php if($cpar->raised_by == request('user.id')): ?>
					<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> edit <?php $__env->endSlot(); ?> edit <?php echo $__env->renderComponent(); ?>
				<?php endif; ?>
				<?php if(request('user.role') != 'default'): ?>
					<?php if($cpar->cpar_number == null): ?>
						<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> Create CPAR Number <?php $__env->endSlot(); ?> Create CPAR Number <?php echo $__env->renderComponent(); ?>
					<?php elseif($cpar->cparReviewed->status == 1 && $cpar->cpar_number <> null): ?>
						<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> Print Reviewed CPAR <?php $__env->endSlot(); ?> Print Reviewed CPAR <?php echo $__env->renderComponent(); ?>
					<?php elseif($cpar->cparReviewed->status == 0 && $cpar->cpar_number == null && $cpar->cparReviewed->status <> 1): ?>
						<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> Print Closed CPAR <?php $__env->endSlot(); ?> Print Closed CPAR <?php echo $__env->renderComponent(); ?>
					<?php else: ?>
						<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> review <?php $__env->endSlot(); ?> review <?php echo $__env->renderComponent(); ?>
					<?php endif; ?>
				<?php endif; ?>
				<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> close <?php $__env->endSlot(); ?> close <?php echo $__env->renderComponent(); ?>
			</td>
			<form method="get" id="edit<?php echo e($cpar->id); ?>"><input type="text" class="form-control hidden" name="cpar_number"></form>
			<form method="get" action="<?php echo e(route('cpars.close', $cpar->id)); ?>" accept-charset="UTF-8" id="close<?php echo e($cpar->id); ?>">
				<?php echo e(csrf_field()); ?>

				<?php echo e(method_field('delete')); ?>

				<input type="text" class="form-control hidden" name="cpar_id">
			</form>
		</tr>
	<?php else: ?>
		<?php if((request('user.branch') == $cpar->branch && request('user.department') == $cpar->department) || request('user.id') == $cpar->raised_by): ?>
			<tr>
				<td><?php echo e($cpar->cpar_number); ?></td>
				<td>
					<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($employee->id == $cpar->raised_by): ?>
							<?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</td>
				<td><?php echo $cpar->severity; ?></td>
				<td><?php echo e($cpar->created_at->toDayDateTimeString()); ?></td>
				<td>
					<?php echo $__env->make('components.status', compact('cpar'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</td>
				<td>
					<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> view <?php $__env->endSlot(); ?> view <?php echo $__env->renderComponent(); ?>
					<?php if($cpar->raised_by == request('user.id')): ?>
						<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> edit <?php $__env->endSlot(); ?> edit <?php echo $__env->renderComponent(); ?>
					<?php endif; ?>
					<?php if(! App\HelperClasses\User::isDefault()): ?>
						<?php if($cpar->cpar_number == null): ?>
							<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> Create CPAR Number <?php $__env->endSlot(); ?> Create CPAR Number <?php echo $__env->renderComponent(); ?>
						<?php elseif($cpar->cparReviewed->status == 1 && $cpar->cpar_number <> null): ?>
							<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> Print Reviewed CPAR <?php $__env->endSlot(); ?> Print Reviewed CPAR <?php echo $__env->renderComponent(); ?>
						<?php elseif($cpar->cparReviewed->status == 0 && $cpar->cpar_number == null && $cpar->cparReviewed->status <> 1): ?>
							<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> Print Closed CPAR <?php $__env->endSlot(); ?> Print Closed CPAR <?php echo $__env->renderComponent(); ?>
						<?php else: ?>
							<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> review <?php $__env->endSlot(); ?> review <?php echo $__env->renderComponent(); ?>
						<?php endif; ?>
					<?php endif; ?>
					<?php $__env->startComponent('components.button-state', compact('cpar')); ?> <?php $__env->slot('title'); ?> close <?php $__env->endSlot(); ?> close <?php echo $__env->renderComponent(); ?>
				</td>
				<form method="get" id="edit<?php echo e($cpar->id); ?>"><input type="text" class="form-control hidden" name="cpar_number"></form>
				<form method="get" action="<?php echo e(route('cpars.close', $cpar->id)); ?>" accept-charset="UTF-8" id="close<?php echo e($cpar->id); ?>">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('delete')); ?>

					<input type="text" class="form-control hidden" name="cpar_id">
				</form>
			</tr>
		<?php else: ?>
			<?php continue; ?>
		<?php endif; ?>
	<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
