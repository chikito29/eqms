<?php $__env->startSection('page-title'); ?> Create CPAR | eQMS <?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-actions'); ?> active <?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="page-content-wrap">

        <div class="page-title">
            <h2><span class="fa fa-pencil"></span> CORRECTIVE AND PREVENTIVE ACTION REPORT FORM</h2>
        </div>

        <div class="row">
            <div class="col-md-9">

                <form enctype="multipart/form-data" class="form-horizontal" action="/cpars" method="POST" role="form">
                    <?php echo e(csrf_field()); ?>

                    
                    <input type="text" class="hidden" value="<?php echo e(request('user.id')); ?>" name="raised_by"/>
                    <input type="text" class="hidden" name="chief" value="Temporary"/>
                    <input type="text" class="hidden" name="link" id="link"/>
                    
                    <div class="panel panel-default">
                        <div class="panel-body form-group-separated">
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Raised By <?php $__env->endSlot(); ?>
                                <?php echo e(request('user.first_name'). ' ' .request('user.last_name')); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <div class="form-group">
                                <label class="col-md-3 col-xs-12 control-label">Department</label>
                                <div class="col-md-5 col-xs-16">
                                    <select name="department" class="form-control select" id="department-select">
                                        <option>Accounting</option>
                                        <option>Human Resource</option>
                                        <option>Information Technology</option>
                                        <option>Internal Audit</option>
                                        <option>Training</option>
                                        <option>Research and Development</option>
                                        <option>Quality Management Representative</option>
                                    </select>
                                    <span class="help-block" id="department-hint"></span>
                                </div>
                                <div class="col-md-4 col-xs-12 <?php if(session('branch')): ?> has-error <?php endif; ?>">
                                    <select name="branch" class="form-control select" id="branch-select">
                                        <option selected disabled>Branch</option>
                                        <option>Bacolod</option>
                                        <option>Cebu</option>
                                        <option>Davao</option>
                                        <option>Iloilo</option>
                                        <option>Makati</option>
                                    </select>
                                    <?php if(session('branch')): ?> <span class="text text-danger"><strong><?php echo e(session()->pull('branch')); ?></strong></span> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 col-xs-12 control-label">Severity Of Findings</label>
                                <div class="col-md-9 col-xs-12">
                                    <select class="form-control select" name="severity" id="severity-select">
                                        <option>Observation</option>
                                        <option>Minor</option>
                                        <option>Major</option>
                                    </select>
                                    <span class="help-block"></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 col-xs-12 control-label">Procedure/Process/Scope/Other References</label>
                                <div class="col-md-9 col-xs-12">
                                    <select class="form-control select" name="reference" id="reference" onchange="showLink()" data-live-search="true">
                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $section->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option id="<?php echo e($document->id); ?>" value="<?php echo e($document->id); ?>"><?php echo e($document->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select> <br><br>
                                    <h6><span id="span-reference"></span></h6>
                                    <input type="text" class="tagsinput" name="tags"  value="<?php echo e(old('tags')); ?>"/>
                                    <?php if($errors->first('tags')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('tags')); ?> <?php echo $__env->renderComponent(); ?> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 col-xs-12 control-label">Source Of Non-Comformity</label>
                                <div class="col-md-9 col-xs-12">
                                    <select class="form-control select" name="source" id="source-select">
                                        <option>External</option>
                                        <option>Internal</option>
                                        <option>Operational Performance</option>
                                        <option>Customer Feedback</option>
                                        <option>Customer Complain</option>
                                    </select>
                                    <span class="help-block"></span>
                                </div>
                            </div>
                            <div class="form-group <?php if($errors->first('other_source')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-5 control-label">Others: (Please specify)</label>
                                <div class="col-md-9 col-xs-7">
                                    <textarea class="form-control" rows="3" name="other_source"><?php echo e(old('other_source')); ?></textarea>
                                    <?php if($errors->first('other_source')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('other_source')); ?> <?php echo $__env->renderComponent(); ?> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group <?php if($errors->first('details')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-5 control-label">Details</label>
                                <div class="col-md-9 col-xs-7">
                                    <textarea class="form-control" rows="5" name="details"><?php echo e(old('details')); ?></textarea>
                                    <?php if($errors->first('details')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('details')); ?> <?php echo $__env->renderComponent(); ?> <?php endif; ?>
                                </div>
                            </div>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Person Reporting To Non-Conformity <?php $__env->endSlot(); ?>
                                <?php echo e(request('user.first_name'). ' ' .request('user.last_name')); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <div class="form-group <?php if($errors->first('person_responsible')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-12 control-label"> Person Responsible For Taking The CPAR </label>
                                <div class="col-md-9 col-xs-12">
                                    <select class="form-control select" name="person_responsible" id="person-responsible" data-live-search="true"></select>
                                    <?php if($errors->first('person_responsible')): ?>
										<?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('person_responsible')); ?> <?php echo $__env->renderComponent(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group <?php if($errors->first('proposed-date')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-12 control-label">Proposed Corrective Action Complete Date</label>
                                <div class="col-md-9 col-xs-12">
                                    <input type="text" class="form-control datepicker" name="proposed_date" value="<?php echo e(old('proposed_date')); ?>"/>
                                    <?php if($errors->first('proposed_date')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('proposed_date')); ?> <?php echo $__env->renderComponent(); ?> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 col-xs-12 control-label">Department Head</label>
                                <div class="col-md-9 col-xs-12">
                                    <select class="form-control select" name="chief" id="chief" data-live-search="true"></select>
                                </div>
                            </div>
							<div class="form-group">
								<label class="col-md-3 col-xs-5 control-label">Attachment</label>
								<div class="col-md-9 col-xs-7">
									<input type="file" multiple id="file-simple" name="attachments[]"/>
									<span class="help-block">Attach document / scanned document if needed.</span>
								</div>
							</div>
                            <div class="form-group">
                                <div class="col-md-12 col-xs-5">
                                    <button class="btn btn-primary btn-rounded pull-right">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

            </div>

            <div class="col-md-3">

                <div class="panel panel-default form-horizontal">
                    <div class="panel-body">
                        <h3><span class="fa fa-info-circle"></span> Quick Info</h3>
                        <p>Some quick info about this user</p>
                    </div>
                    <div class="panel-body form-group-separated">
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Role</label>
                            <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.role')); ?></div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Username</label>
                            <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.username')); ?></div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Department</label>
                            <div class="col-md-8 col-xs-7"><?php echo e(request('user.department')); ?></div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Branch</label>
                            <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.branch')); ?></div>
                        </div>
                    </div>

                </div>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/summernote/summernote.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/bootstrap/bootstrap-select.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/fileinput/fileinput.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/tagsinput/jquery.tagsinput.min.js')); ?>"></script>
    <script type="text/javascript">
        $(function(){
            $("#file-simple").fileinput({
                showUpload: false,
                showCaption: true,
                uploadUrl: "<?php echo e(route('revision-requests.store')); ?>",
                browseClass: "btn btn-primary",
                browseLabel: "Browse Document",
                allowedFileExtensions : ['.jpg']
            });

            /* Hidden placeholder */
            $('select option[disabled]:first-child').css('display', 'none');

            /* Populate old('') elements */
            $('#department-select').val('<?php echo e(old('department')); ?>');
            $('#department-select').selectpicker('refresh');
            $('#branch-select').val('<?php echo e(old('branch')); ?>');
            $('#branch-select').selectpicker('refresh');
            $('#severity-select').val('<?php echo e(old('severity')); ?>');
            $('#severity-select').selectpicker('refresh');
            $('#reference').val('<?php echo e(old('reference')); ?>');
            $('#reference').selectpicker('refresh');
            $('#source-select').val('<?php echo e(old('source')); ?>');
            $('#source-select').selectpicker('refresh');
            $('#span-reference').html('<?php echo old('link'); ?>');

            employeeOptions = "";
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(request('user.id') == $employee->id): ?> <?php continue; ?>
                <?php else: ?> employeeOptions+= '<option value="<?php echo e($employee->id); ?>"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></option>';
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            $('#person-responsible').empty().append(employeeOptions);

            chiefOptions = "";

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->chief == 1 && (request('user.id') != $user->id)): ?>
                    chiefOptions+= '<option value="<?php echo e($user->id); ?>"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></option>';
                <?php else: ?>
					<?php continue; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        $('#chief').empty().append(chiefOptions);
        });

        $('#summernote').summernote({
            height: 300,
            toolbar: [
                ['misc', ['fullscreen']],
            ]
        });
    </script>

    <script>
        function showLink() {
            $('#span-reference').html("<a href="
                + "\"/documents/"
                + $('#reference').children(':selected').attr('id')
                + "\""
                + " target=\"_blank\">"
                + "Open "
                + $('#reference').children(':selected').html()
                + " in new tab"
                + "</a>");

            $('#link').val("<a href="
                + "\"/documents/"
                + $('#reference').children(':selected').attr('id')
                + "\""
                + " target=\"_blank\">"
                + "Open "
                + $('#reference').children(':selected').html()
                + " in new tab"
                + "</a>");
        }

        $('#department-select').on('change', function() {
            $('#department-hint').empty().append("<span class=\"text text-info\">Do not forget to choose a branch too.</span>");
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>