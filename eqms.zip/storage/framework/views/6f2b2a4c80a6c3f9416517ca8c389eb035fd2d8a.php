<?php $__env->startSection('content'); ?>

        <ul class="collapsible popout" data-collapsible="accordion">

            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="collapsible-header"><?php echo e($item->getName() . ' (' . $item->getDescription() . ')'); ?></div>
                    <div class="collapsible-body">
                        <div class="row">
                            <form  class="col s12" method="POST" action="<?php echo url('niceartisan/item/' . $item->getName()); ?>">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" name="command" value="<?php echo e($item->getName()); ?>">
                                <?php if(count($item->getDefinition()->getArguments()) > 0): ?>
                                  <fieldset>
                                      <legend>Arguments</legend>
                                      <?php $__currentLoopData = $item->getDefinition()->getArguments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $argument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="input-field">
                                                <input type="text" name="argument_<?php echo e($argument->getName()); ?>" placeholder="<?php echo e(is_array($argument->getDefault()) ? '' : $argument->getDefault()); ?>">
                                                <label><?php echo e($argument->getName() . ' (' . $argument->getDescription()); ?>)</label>
                                            </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </fieldset>
                                <?php endif; ?>
                                <?php if(count($item->getDefinition()->getOptions()) > 0): ?>
                                    <fieldset>
                                        <legend>Options</legend>
                                        <?php $__currentLoopData = $item->getDefinition()->getOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($option->getDefault() !== false): ?>
                                                <div class="input-field">
                                                    <input type="text" name="option_<?php echo e($option->getName()); ?>" placeholder="<?php echo e(is_array($option->getDefault()) ? '' : $option->getDefault()); ?>">
                                                    <label>--<?php echo e($option->getName() . ' (' . $option->getDescription()); ?>)</span></label>
                                                </div>
                                            <?php else: ?>
                                                <p>
                                                    <input type="checkbox" id="<?php echo e($option->getDescription()); ?>" name="option_<?php echo e($option->getName()); ?>">
                                                    <label for="<?php echo e($option->getDescription()); ?>"><?php echo e($option->getDescription()); ?></label>
                                                </p>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </fieldset>
                                <?php endif; ?>
                                <br>
                                <div class="col s12 center-align">
                                    <button class="btn waves-effect waves-light" type="submit" name="action">Go !</button>
                                </div>
                            </form> 
                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('NiceArtisan::template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>