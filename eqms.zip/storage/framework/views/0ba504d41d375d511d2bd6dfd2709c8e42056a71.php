<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Nice Artisan</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.3/css/materialize.min.css">
    </head>

    <body>

        <div class="container">

            <br>

            <h1 class="center-align">Nice Artisan</h1>

            <nav>
                <div class="nav-wrapper">
                    <ul id="nav-mobile" class="left hide-on-med-and-down">
                        <?php for($i = 0; $i < count($options); $i++): ?>
                            <?php if($i == 0): ?>
                                <li <?php echo request()->is('niceartisan') || request()->is('niceartisan/' . $options[$i]) ? 'class="active"' : ''; ?>>
                            <?php else: ?>
                                <li <?php echo request()->is('niceartisan/' . $options[$i]) ? 'class="active"' : ''; ?>>
                            <?php endif; ?>
                                    <a href="<?php echo url('niceartisan/' . $options[$i]); ?>"><?php echo e(ucfirst($options[$i])); ?></a>
                                </li>  
                        <?php endfor; ?>
                    </ul>
                </div>
            </nav>
            
            <div class="row">

                <?php if(count($errors) > 0): ?>
                    <div class="col s12">
                      <div class="card red accent-4">
                        <div class="card-content white-text">
                            <span class="card-title">Whoops !<small> There were some problems with your input.</small></span>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      </div>
                    </div>  
                <?php endif; ?>

                <?php if(session('output')): ?>
                    <div class="col s12">
                      <div class="card blue-grey darken-1">
                        <div class="card-content white-text">
                            <span class="card-title">Success !</span>
                            <pre><?php echo session('output'); ?></pre>
                        </div>
                      </div>
                    </div>    
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="col s12">
                      <div class="card red accent-4">
                        <div class="card-content white-text">
                            <span class="card-title">Error !</span>
                            <pre><?php echo session('error'); ?></pre>
                        </div>
                      </div>
                    </div>  
                <?php endif; ?>
                
            </div>

            <?php echo $__env->yieldContent('content'); ?>

        </div>
        
        <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.3/js/materialize.min.js"></script>

    </body>
</html>
