<?php $__env->startComponent('mail::message'); ?>
# Processing Revision Request

The Revision Request you submitted for <a href="<?php echo e(route('documents.show', $revisionRequest->reference_document->id)); ?>"><?php echo e($revisionRequest->reference_document->title); ?></a> was reviewed and has been approved by the QMR. Your Revision Request is now waiting for CEO's Approval.

<br><b>Reason for recommendation: </b>
<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($revisionRequest->section_b->recommendation_reason); ?>

<?php echo $__env->renderComponent(); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php $__env->startComponent('mail::subcopy'); ?>
<p style="text-align: center;">This is a computer generated email. Please do not reply. <br> For inquiries kindly email as at <a href="#">it@newsim.ph</a></p>
<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?>
