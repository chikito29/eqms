<?php $__env->startSection('page-title'); ?>Revision Request | eQMS <?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-view'); ?> active <?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">

    <div class="page-title">
        <h2><span class="fa fa-pencil"></span> Revision Request</h2>
    </div>

    <div class="row">
        <div class="col-md-9">

            <!-- Start Section A -->
            <form class="form-horizontal">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <h3>Section A: Formal Request</h3>
                        <p>This is to formalize a request for a revision to the document as follows:</p>
                    </div>
                    <div class="panel-body form-group-separated">
                        <?php  $appeal = \App\RevisionRequest::find($revisionRequest->revision_request_id)  ?>
                        <?php if($appeal <> null && ($revisionRequest->appeal_id <> null && ($appeal->status == 'Denied' || $appeal->status == 'Approved'))): ?>
                            <?php echo $__env->make('revisionrequests.appeal-elements.appeal-link', ['revisioRequest' => $revisionRequest], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($revisionRequest->appeal_id <> null): ?>
                            <div class="form-group" style="text-align: center;">
                                <label class="control-label" style="padding: 10px; font-weight: bold;">Appeal is still on review.</label>
                            </div>
                        <?php elseif($revisionRequest->is_appeal == 1): ?>
                            <?php echo $__env->make('revisionrequests.appeal-elements.denied_link', ['revisionRequest' => $revisionRequest], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">Revision Request No.</label>
                            <div class="col-md-9 col-xs-7">
                                <label class="control-label"><?php echo e($revisionRequest->revision_request_number); ?></label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">Date Submitted</label>
                            <div class="col-md-9 col-xs-7">
                                <label class="control-label"><?php echo e($revisionRequest->created_at->toFormattedDateString()); ?></label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">Reference Document</label>
                            <div class="col-md-9 col-xs-7">
                                <label class="control-label"><a href="<?php echo e(route('documents.show', $revisionRequest->reference_document->id)); ?>" target="_blank"><?php echo e($revisionRequest->reference_document->title); ?> <span class="fa fa-external-link"></span></a></label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-12 control-label">Section / Page / Process</label>
                            <div class="col-md-9 col-xs-12">
                                <ul class="list-tags">
                                    <?php $__currentLoopData = explode( ',', $revisionRequest->reference_document_tags ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference_document_tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="#"><?php echo e($reference_document_tags); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">Attachments</label>
                            <div class="col-md-9 col-xs-7">
                                <?php if($revisionRequest->is_appeal == 1 && $revisionRequest->uses_old_attachment == 1): ?>
                                    <?php $__currentLoopData = \App\RevisionRequest::find($revisionRequest->revision_request_id)->attachments->where('section', 'revision-request-a'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="control-label" href="<?php echo e(url($attachment->file_path)); ?>" target="_blank"><?php echo e($attachment->file_name); ?></a><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php elseif($revisionRequest->is_appeal == 0): ?>
                                    <?php if(count($revisionRequest->attachments->where('section', 'revision-request-a')) > 0): ?>
                                        <?php $__currentLoopData = $revisionRequest->attachments->where('section', 'revision-request-a'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="control-label" href="<?php echo e(url($attachment->file_path)); ?>" target="_blank"><?php echo e($attachment->file_name); ?></a><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <label class="control-label">None</label>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-12 control-label">Reason for Revision</label>
                            <div class="col-md-9 col-xs-12">
                                <div class="panel-body" style="background-color: rgb(249,249,249); padding: 20px; border-radius: 5px;">
                                    <?php echo e($revisionRequest->revision_reason); ?>

                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-12 control-label">Proposed Revision</label>
                            <div class="col-md-9 col-xs-12">

                                <div class="panel-body" style="background-color: rgb(249,249,249); padding: 20px; border-radius: 5px;">
                                    <?php echo $revisionRequest->proposed_revision; ?>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </form>
            <!-- End Section A -->

            <!-- Start Section B -->
            <form enctype="multipart/form-data" class="form-horizontal" action="<?php echo e(route('revision-requests.update', $revisionRequest->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('put')); ?>

                <div class="panel panel-default">
                    <div class="panel-body">
                        <h3>Section B: QMR's Recommendation</h3>
                        <?php if($revisionRequest->section_b): ?>
                        <p><?php echo e($revisionRequest->section_b->created_at->toDayDateTimeString()); ?></p>
                        <?php else: ?>
                        <p>For Approval/Disapproval</p>
                        <?php endif; ?>
                    </div>
                    <div class="panel-body form-group-separated">
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">Recommendation Status</label>
                            <div class="col-md-9 col-xs-7">
                                <?php if( ! $revisionRequest->section_b): ?>
                                <select class="form-control select" name="recommendation_status">
                                    <option>For Approval</option>
                                    <option>For Disapproval</option>
                                </select>
                                <?php else: ?>
                                    <?php if($revisionRequest->section_b->recommendation_status == 'For Approval'): ?>
                                    <label class="control-label"><span class="label label-success label-form" style="color: white;"><?php echo e($revisionRequest->section_b->recommendation_status); ?></span></label>
                                    <?php else: ?>
                                    <label class="control-label"><span class="label label-danger label-form" style="color: white;"><?php echo e($revisionRequest->section_b->recommendation_status); ?></span></label>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group <?php if($errors->has('recommendation_reason')): ?> has-error <?php endif; ?>">
                            <label class="col-md-3 col-xs-5 control-label">Reason for Recommendation / Disapproval</label>
                            <div class="col-md-9 col-xs-7">
                                <?php if( ! $revisionRequest->section_b): ?>
                                <textarea class="form-control" rows="5" name="recommendation_reason" maxlength="600"></textarea>
                                <span class="help-block">Maximum: 600 characters.</span>
								<?php if($errors->has('recommendation_reason')): ?>
								<span class="help-block successful">
									<strong class="text-danger"><?php echo e($errors->first('recommendation_reason')); ?></strong>
								</span>
								<?php endif; ?>
                                <?php else: ?>
                                <div class="panel-body" style="background-color: rgb(249,249,249); padding: 20px; border-radius: 5px;">
                                    <?php echo e($revisionRequest->section_b->recommendation_reason); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-12 col-xs-12">
                                <?php if( ! $revisionRequest->section_b): ?>
                                    <button class="btn btn-primary btn-rounded pull-right">Submit</button>
                                <?php else: ?>
                                    <?php if($revisionRequest->section_b->recommendation_status == 'For Approval' && ( ! $revisionRequest->section_c)): ?>
                                    <a href="<?php echo e(route('revision-requests.print', $revisionRequest->id)); ?>" class="btn btn-info btn-rounded pull-right" target="_blank"><span class="fa fa-print"></span> Print</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <!-- End Section B -->

            <!-- Start Section C -->
            <?php if($revisionRequest->section_b): ?>
            <?php if($revisionRequest->section_b->recommendation_status == 'For Approval'): ?>
            <form enctype="multipart/form-data" class="form-horizontal" action="<?php echo e(route('revision-requests.update', $revisionRequest->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('put')); ?>

                <div class="panel panel-default">
                    <div class="panel-body">
                        <h3>Section C: Approval/Disapproval</h3>
                        <?php if($revisionRequest->section_c): ?>
                        <p><?php echo e($revisionRequest->section_c->created_at->toDayDateTimeString()); ?></p>
                        <?php else: ?>
                        <p>For Approval/Disapproval</p>
                        <?php endif; ?>
                    </div>
                    <div class="panel-body form-group-separated">
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">CEO Approval Status</label>
                            <div class="col-md-9 col-xs-7">
                                <?php if( ! $revisionRequest->section_c): ?>
                                <select class="form-control select" name="approved">
                                    <option value=1>Approved</option>
                                    <option value=0>Denied</option>
                                </select>
                                <?php else: ?>
                                    <?php if($revisionRequest->section_c->approved == true): ?>
                                    <label class="control-label"><span class="label label-success label-form" style="color: white;">Approved</span></label>
                                    <?php else: ?>
                                    <label class="control-label"><span class="label label-danger label-form" style="color: white;">Denied</span></label>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">Attachment</label>
                            <div class="col-md-9 col-xs-7">
                                <?php if( ! $revisionRequest->section_c): ?>
                                <input type="file" multiple id="file-simple" name="attachments[]"/>
                                <span class="help-block">Upload the signed revision request by the CEO.</span>
								<?php if($errors->has('attachments')): ?>
								<span class="help-block successful">
									<strong class="text-danger"><?php echo e($errors->first('attachments')); ?></strong>
								</span>
								<?php endif; ?>
                                <?php else: ?>
                                    <?php if(count($revisionRequest->attachments->where('section', 'revision-request-c')) > 0): ?>
                                        <?php $__currentLoopData = $revisionRequest->attachments->where('section', 'revision-request-c'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(url($attachment->file_path)); ?>" target="_blank"><label class="control-label"><?php echo e($attachment->file_name); ?></label></a><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <label class="control-label">None</label>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">Remarks</label>
                            <div class="col-md-9 col-xs-7">
                                <?php if( ! $revisionRequest->section_c): ?>
                                <textarea class="form-control" rows="5" name="ceo_remarks"></textarea>
                                <?php else: ?>
                                <div class="panel-body" style="background-color: rgb(249,249,249); padding: 20px; border-radius: 5px;">
                                    <?php echo e($revisionRequest->section_c->ceo_remarks); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-12 col-xs-5">
                                <?php if( ! $revisionRequest->section_c): ?>
                                <button class="btn btn-primary btn-rounded pull-right">Submit</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <?php endif; ?>
            <?php endif; ?>
            <!-- End Section C -->

			<?php if($errors->has('others')): ?>
				<div class="alert alert-danger" role="alert">
					<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					<strong>Woops!</strong> One of the following fields <em>must</em> be filled:<br>
					<ul>
						<li> <strong>Action Taken</strong> </li>
						<li> <strong>If others, please specify</strong> </li>
					</ul>
				</div>
			<?php endif; ?>

            <!-- Start Section D -->
            <?php if($revisionRequest->section_b && $revisionRequest->section_c): ?>
            <?php if($revisionRequest->section_c->approved): ?>
            <form enctype="multipart/form-data" class="form-horizontal" action="<?php echo e(route('revision-requests.update', $revisionRequest->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('put')); ?>

                <div class="panel panel-default">
                    <div class="panel-body">
                        <h3>Section D: Action Taken</h3>
                        <?php if($revisionRequest->section_d): ?>
                        <p><?php echo e($revisionRequest->section_d->created_at->toDayDateTimeString()); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="panel-body form-group-separated">
                        <div class="form-group">
                            <label class="col-md-3 col-xs-7 control-label">Action Taken</label>
                            <div class="col-md-9 col-xs-5">
                                <?php if( ! $revisionRequest->section_d): ?>
                                <select multiple class="form-control select" name="action_taken[]">
                                    <option>Document Revised</option>
                                    <option>Updated</option>
                                    <option>Distributed to Holders</option>
                                    <option>Others</option>
                                </select>
                                <?php else: ?>
                                <ul class="list-tags">
                                    <?php $__currentLoopData = explode(',', $revisionRequest->section_d->action_taken ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action_taken): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="#"><?php echo e($action_taken); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if( ! $revisionRequest->section_d): ?>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">If others, please specify</label>
                            <div class="col-md-9 col-xs-7">
                                <textarea class="form-control" rows="5" name="others"></textarea>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="form-group">
                            <label class="col-md-3 col-xs-5 control-label">Others</label>
                            <div class="col-md-9 col-xs-7">
                                <div class="panel-body" style="background-color: rgb(249,249,249); padding: 20px; border-radius: 5px;">
                                    <?php echo e($revisionRequest->section_d->others); ?>

                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <div class="col-md-12 col-xs-5">
                                <?php if( ! $revisionRequest->section_d): ?>
                                <button class="btn btn-primary btn-rounded pull-right">Submit</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <?php endif; ?>
            <?php endif; ?>
            <!-- End Section D -->

        </div>
        <div class="col-md-3">

            <div class="panel panel-default form-horizontal">
                <div class="panel-body">
                    <h3><span class="fa fa-info-circle"></span> Quick Info</h3>
                    <p>Some quick info about this user</p>
                </div>
                <div class="panel-body form-group-separated">
                    <div class="form-group">
                        <label class="col-md-4 col-xs-5 control-label">Role</label>
                        <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.role')); ?></div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-4 col-xs-5 control-label">Username</label>
                        <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.username')); ?></div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-4 col-xs-5 control-label">Department</label>
                        <div class="col-md-8 col-xs-7"><?php echo e(request('user.department')); ?></div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-4 col-xs-5 control-label">Branch</label>
                        <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.branch')); ?></div>
                    </div>
                </div>

            </div>

        </div>
    </div>

</div>
<!-- END PAGE CONTENT WRAPPER -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(url('js/plugins/bootstrap/bootstrap-select.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/plugins/fileinput/fileinput.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/plugins/tagsinput/jquery.tagsinput.min.js')); ?>"></script>
<script type="text/javascript">
    $(function(){
        $("#file-simple").fileinput({
            showUpload: false,
            showCaption: true,
            uploadUrl: "<?php echo e(route('revision-requests.store')); ?>",
            browseClass: "btn btn-primary",
            browseLabel: "Browse Document",
            allowedFileExtensions : ['.jpg']
        });
    });

    if('<?php echo e($revisionRequest->is_appeal); ?>' == '1') {
        $('.page-title').html('<h2><span class="fa fa-legal"></span> Appeal</h2>');
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>