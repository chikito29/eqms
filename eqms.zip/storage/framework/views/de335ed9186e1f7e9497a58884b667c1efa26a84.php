<?php $__env->startSection('page-title'); ?> Create CPAR | eQMS <?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-audit-findings'); ?> active <?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="page-content-wrap">

        <div class="page-title">
            <h2><span class="fa fa-pencil"></span> CORRECTIVE AND PREVENTIVE ACTION REPORT FORM</h2>
        </div>

        <div class="row">
            <div class="col-md-9">

                <form enctype="multipart/form-data" class="form-horizontal" action="/cpars/review/<?php echo e($cpar->id); ?>" method="POST" role="form" id="review-form">
                    <?php echo e(csrf_field()); ?>

                    <div class="panel panel-default">
                        <div class="panel-body form-group-separated">
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Raised By <?php $__env->endSlot(); ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->id == $cpar->raised_by): ?>
                                        <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Department <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->department); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Branch <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->branch); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Severity Of Findings <?php $__env->endSlot(); ?>
                                <?php echo e(strip_tags(str_replace('&nbsp;', '', $cpar->severity))); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <div class="form-group">
                                <label class="col-md-3 col-xs-12 control-label">Procedure/Process/Scope/Other References</label>
                                <div class="col-md-9 col-xs-12">
                                    <textarea class="summernote" name="proposed_revision" id="summernote" disabled><?php echo $body; ?></textarea>
                                </div>
                            </div>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Tags <?php $__env->endSlot(); ?>
                                <?php $__currentLoopData = explode(',', $cpar->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span style="border: solid 1px; border-color: rgb(220,220,220); padding: 4px 13px; border-radius: 3px; background-color: rgb(250,250,250);"><span class="fa fa-tag"> <?php echo e($tag); ?></span></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Source Of Non-Conformity <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->source); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php if($cpar->other_source): ?>
                                <?php $__env->startComponent('components.show-multi-line'); ?>
                                    <?php $__env->slot('label'); ?> Others: (Please specify) <?php $__env->endSlot(); ?>
                                    <?php echo e($cpar->other_source); ?>

                                <?php echo $__env->renderComponent(); ?>
                            <?php endif; ?>
                            <?php $__env->startComponent('components.show-multi-line'); ?>
                                <?php $__env->slot('label'); ?> Details <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->details); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Name <?php $__env->endSlot(); ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->id == $cpar->person_reporting): ?>
                                        <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__env->slot('help'); ?> Person Reporting To Non-Conformity <?php $__env->endSlot(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Name <?php $__env->endSlot(); ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->id == $cpar->person_responsible): ?>
                                        <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__env->slot('help'); ?> Person Responsible For Taking The CPAR <?php $__env->endSlot(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-multi-line'); ?>
                                <?php $__env->slot('label'); ?> Correction <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->correction); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-multi-line'); ?>
                                <?php $__env->slot('label'); ?> Root Cause Analysis <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->root_cause); ?>

                                <?php $__env->slot('help'); ?> What Failed In The System To Allow This Non-Conformance To Occur? <?php $__env->endSlot(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-multi-line'); ?>
                                <?php $__env->slot('label'); ?> Corrective/Preventive Action <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->cp_action); ?>

                                <?php $__env->slot('help'); ?> Specific Details Of Corrective Action Taken To Prevent Recurrence/Occurrence <?php $__env->endSlot(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Proposed Corrective Action Complete Date <?php $__env->endSlot(); ?>
                                <?php echo e(Carbon\Carbon::parse($cpar->proposed_date)->toFormattedDateString()); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <div class="form-group <?php if($errors->first('date_completed')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-12 control-label">Corrective/Preventive Complete Date</label>
                                <div class="col-md-9 col-xs-12">
                                    <input type="text" class="form-control datepicker" name="date_completed" value="<?php echo e($cpar->date_completed); ?>"/>
                                    <?php if($errors->first('date_completed')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('date_completed')); ?> <?php echo $__env->renderComponent(); ?> <?php endif; ?>
                                </div>
                            </div>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Department Head <?php $__env->endSlot(); ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($employee->id == $cpar->chief): ?>
                                        <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.show-single-line'); ?>
                                <?php $__env->slot('label'); ?> Date Confirmed By Department Head <?php $__env->endSlot(); ?>
                                <?php echo e($cpar->date_confirmed); ?>

                            <?php echo $__env->renderComponent(); ?>
                            <div class="form-group">
                                <div class="col-md-12">
                                    <h4><strong>To Be Filled By The QMR / Auditor</strong></h4>
                                </div>
                            </div>
                            <div class="form-group <?php if($errors->first('cpar-acceptance')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-12 control-label">Acceptance Of CPAR</label>
                                <div class="col-md-9 col-xs-12">
                                    <textarea class="form-control" rows="4" name="cpar_acceptance"><?php echo e($cpar->cpar_acceptance); ?></textarea>
                                    <?php if($errors->first('cpar_acceptance')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('cpar_acceptance')); ?> <?php echo $__env->renderComponent(); ?>
                                    <?php else: ?> <span class="help-block">Comments If Any</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group <?php if($errors->first('date-accepted')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-12 control-label">Date CPAR Accepted</label>
                                <div class="col-md-9 col-xs-12">
                                    <input type="text" class="form-control datepicker" name="date_accepted" value="<?php echo e($cpar->date_accepted); ?>">
                                    <?php if($errors->first('date_accepted')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('date_accepted')); ?> <?php echo $__env->renderComponent(); ?> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group <?php if($errors->first('verified-by')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-12 control-label">Name</label>
                                <div class="col-md-9 col-xs-12">
                                    <input type="text" class="form-control" name="verified_by"
                                       <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <?php if($employee->id == $cpar->verified_by): ?>
                                                value="<?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?>"
                                           <?php endif; ?>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    />
                                    <?php if($errors->first('verified_by')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('verified_by')); ?> <?php echo $__env->renderComponent(); ?>
                                    <?php else: ?><span class="help-block">QMR / AUDITOR / CEO</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group <?php if($errors->first('verification-date')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-12 control-label">Verification Date</label>
                                <div class="col-md-9 col-xs-12">
                                    <input type="text" class="form-control datepicker" name="verification_date" value="<?php echo e($cpar->date_verified); ?>"/>
                                    <?php if($errors->first('verification_date')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('verification_date')); ?> <?php echo $__env->renderComponent(); ?> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group <?php if($errors->first('result')): ?> has-error <?php endif; ?>">
                                <label class="col-md-3 col-xs-5 control-label">Result Of Verification</label>
                                <div class="col-md-9 col-xs-7">
                                    <textarea class="form-control" rows="5" name="result"><?php echo e($cpar->result); ?></textarea>
                                    <?php if($errors->first('result')): ?> <?php $__env->startComponent('layouts.error'); ?> <?php echo e($errors->first('result')); ?> <?php echo $__env->renderComponent(); ?> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 col-xs-5 control-label">Add Attachment/s</label>
                                <div class="col-md-9 col-xs-7">
                                    <input type="file" multiple id="file-simple" name="attachments[]"/>
                                    <span class="help-block">Attach document / scanned document if needed.</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 col-xs-5 control-label">Attachment/s</label>
                                <div class="col-md-9 col-xs-7">
									<div class="gallery" id="links">
										<?php if($cpar->attachments->count() > 0): ?>
											<?php $__currentLoopData = $cpar->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<a class="gallery-item" href="<?php echo e(asset($attachment->file_path)); ?>">
														<div class="image">
															<img src="<?php echo e(asset($attachment->file_path)); ?>"/>
														</div>
														<div class="meta">
															<strong><?php echo e($attachment->file_name); ?></strong>
															<span>added by <?php echo e($attachment->uploaded_by); ?></span>
														</div>
													</a>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
											No Attachment Avaible For This CPAR
										<?php endif; ?>
									</div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12 col-xs-5">
                                    <button type="button" class="btn btn-primary btn-rounded pull-right" onclick="reviewCpar()">Finalize Review</button>
                                    <button type="button" class="btn btn-info btn-rounded pull-right" onclick="saveAsDraft()">Save Draft</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

            </div>

            <div class="col-md-3">

                <div class="panel panel-default form-horizontal">
                    <div class="panel-body">
                        <h3><span class="fa fa-info-circle"></span> Quick Info</h3>
                        <p>Some quick info about this user</p>
                    </div>
                    <div class="panel-body form-group-separated">
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Role</label>
                            <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.role')); ?></div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Username</label>
                            <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.username')); ?></div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Department</label>
                            <div class="col-md-8 col-xs-7"><?php echo e(request('user.department')); ?></div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 col-xs-5 control-label">Branch</label>
                            <div class="col-md-8 col-xs-7 line-height-30"><?php echo e(request('user.branch')); ?></div>
                        </div>
                    </div>

                </div>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/summernote/summernote.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/bootstrap/bootstrap-select.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/fileinput/fileinput.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/tagsinput/jquery.tagsinput.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/plugins/summernote/summernote.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(url('js/plugins/blueimp/jquery.blueimp-gallery.min.js')); ?>"></script>
    <script type="text/javascript">
        $(function(){
            $("#file-simple").fileinput({
                showUpload: false,
                showCaption: true,
                uploadUrl: "<?php echo e(route('revision-requests.store')); ?>",
                browseClass: "btn btn-primary",
                browseLabel: "Browse Document",
                allowedFileExtensions : ['.jpg']
            });
        });

        $('#summernote').summernote({
            height: 300,
            toolbar: [
                ['misc', ['fullscreen']],
            ]
        });
    </script>

    <script>
        $(function() {
            $('#department').val('<?php echo e($cpar->department); ?>');
        });

        function reviewCpar() {
            $('#confirmation-modal-trigger').click();
            $('#confirmation-modal-body').html('Finalize CPAR review? This cannot  be undone. If this is unintentional please click Cancel, otherwise, click Okay');
            $('#confirmation-modal-okay-button').attr('onclick', '$(\'#review-form\').submit();');
        }

        function saveAsDraft() {
            $('#confirmation-modal-trigger').click();
            $('#confirmation-modal-body').html('Attachments will not be saved when saving CPAR as draft.');
            $('#confirmation-modal-okay-button').attr('onclick', 'save()');
        }

        function save(){
            $('#review-form').attr('action', '<?php echo e(route('cpars.save-as-draft', $cpar->id)); ?>');
            $('#review-form').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
    <a class="btn btn-primary hidden" data-toggle="modal" href="#confirmation-modal" id="confirmation-modal-trigger">Trigger modal</a>
    <div class="modal fade" id="confirmation-modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Confirm action</h4>
                </div>
                <div class="modal-body" id="confirmation-modal-body"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmation-modal-okay-button">Okay</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>