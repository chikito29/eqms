<?php if($slot == 'New'): ?>
    <span class="label label-info" style="color: white;"><?php echo e($slot); ?></span>
<?php elseif($slot == 'Processing'): ?>
    <span class="label label-warning" style="color: white;"><?php echo e($slot); ?></span>
<?php elseif($slot == 'Approved'): ?>
    <span class="label label-success" style="color: white;"><?php echo e($slot); ?></span>
<?php elseif($slot == 'Denied'): ?>
    <span class="label	label-danger" style="color: white;">
		<?php echo e($slot); ?>

		<?php if($revisionRequest->has_appeal == 1): ?>
			<span class="glyphicon glyphicon-link" style="color:black"></span>
		<?php endif; ?>
	</span>

<?php elseif($slot == 'Appeal'): ?>
	<span class="label label-warning" style="color: white;"><?php echo e($slot); ?></span>
<?php endif; ?>
