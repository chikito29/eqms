<?php if($slot == 'For Approval'): ?>
    <span class="label label-success" style="color: white;"><?php echo e($slot); ?></span>
<?php else: ?>
    <span class="label label-danger" style="color: white;"><?php echo e($slot); ?></span>
<?php endif; ?>
