<?php $__env->startSection('page-title'); ?>
    Procedures | eQMS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-actions'); ?> active <?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="page-content-wrap" style="margin-top: -25px;">
        <div class="x-content" >
            <div class="x-content-inner" style="margin-top:-20px; height: 90vh;">
                <div class="row">
                    <div class="col-md-12">
                        <div class="x-block">
                            <div class="x-block-head">
                                <h3>New Procedures</h3>
                            </div>
                            <div class="x-block-content x-todo" style="margin-bottom: 20px;">
                                <div class="x-todo-header">
                                    <form class="form-horizontal" action="<?php echo e(route('sections.store')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <label class="col-md-2 col-xs-12 control-label">Procedure Name</label>
                                            <div class="col-md-6 col-xs-12">
                                                <input type="text" class="form-control" name="name" style="margin-top:7px;"/>
                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block successful">
                                                        <strong class="text-danger"><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-2">
                                                <button class="btn btn-success"> SAVE</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <table class="table table-striped" id="table-application">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Added By</th>
                                            <th>Last Updated</th>
                                            <th with="120">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($section->id); ?></td>
                                                <td><?php echo e($section->name); ?></td>
                                                <td><?php echo e($section->created_by); ?></td>
                                                <td><?php echo e($section->updated_at->toDayDateTimeString()); ?></td>
                                                <td>
                                                    <button class="btn btn-default btn-rounded btn-sm" onclick="location.href='<?php echo e(route('sections.edit', $section->id)); ?>';"><span class="fa fa-pencil"></span></button>
                                                    <button class="btn btn-danger btn-rounded btn-sm" type="button" name="button" onclick="delete_section(<?php echo e($section->id); ?>)"><span class="fa fa-times"></span></button>
                                                </td>
                                                <form method="POST" action="<?php echo e(route('sections.destroy', $section->id)); ?>" accept-charset="UTF-8" id="form-delete<?php echo e($section->id); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('delete')); ?>

                                                </form>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('message-box'); ?>
    <!-- MESSAGE BOX-->
    <div class="message-box animated fadeIn" data-sound="alert" id="mb-remove-section">
        <div class="mb-container">
            <div class="mb-middle">
                <div class="mb-title"><span class="fa fa-times"></span> Remove <strong>Procedure</strong> ?</div>
                <div class="mb-content">
                    <p>Are you sure you want to remove this Procedure?</p>
                    <p>Documents belong to this procedure will not be available</p>
                    <p>Press Yes if you sure.</p>
                </div>
                <div class="mb-footer">
                    <div class="pull-right">
                        <button class="btn btn-success btn-lg mb-control-yes">Yes</button>
                        <button class="btn btn-default btn-lg mb-control-close">No</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END MESSAGE BOX-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function delete_section(row){
        var box = $('#mb-remove-section');
        box.addClass("open");
        box.find(".mb-control-yes").on("click",
            function(){
                box.removeClass("open");
                document.getElementById('form-delete' + row).submit();
            }
        );
    }

    function edit_document(row){
        document.getElementById('form-edit' + row).submit();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>