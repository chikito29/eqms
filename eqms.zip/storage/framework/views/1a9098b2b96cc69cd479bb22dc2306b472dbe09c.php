<?php $__env->startComponent('mail::message'); ?>
# CPAR has been answered

The CPAR that has been issued to
<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($employee->id == $cpar->person_responsible): ?>
        <strong><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></strong>
        <?php break; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($cpar->created_at->diffForHumans()); ?> has been answered
and needs to be validated before the QMR's review process to take place.

<?php $__env->startComponent('mail::button', ['url' => route('cpars.verify', $cpar->id)]); ?>
    Click here to verify cpar
<?php echo $__env->renderComponent(); ?>

Thanks,
<?php echo e(config('app.name')); ?>


<?php $__env->slot('subcopy'); ?>
    <p style="text-align: center;">This is a computer generated email. Please do not reply. For inquiries kindly email as at <a href="#">it@newsim.ph</a></p>
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
