<?php

namespace App\Http\Controllers;

use App\DocumentVersion;
use Illuminate\Http\Request;

class DocumentVersionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DocumentVersion  $documentVersion
     * @return \Illuminate\Http\Response
     */
    public function show(DocumentVersion $documentVersion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DocumentVersion  $documentVersion
     * @return \Illuminate\Http\Response
     */
    public function edit(DocumentVersion $documentVersion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DocumentVersion  $documentVersion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DocumentVersion $documentVersion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DocumentVersion  $documentVersion
     * @return \Illuminate\Http\Response
     */
    public function destroy(DocumentVersion $documentVersion)
    {
        //
    }
}
